package pepperfry;
 
import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.List;
 
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.interactions.Actions;
 
public class ProductListAutomation {
	public static WebDriver driver;
	
 
	public void Driver(String browser) throws IOException {
 
    if(browser.equalsIgnoreCase("Chrome")){
			
			ChromeOptions options1 = new ChromeOptions();
			options1.addArguments("--disable-notifications");
			options1.addArguments("--disable-popup-blocking");
			driver = new ChromeDriver(options1);
			driver.manage().window().maximize();
			System.out.println("Chrome is Launched.");
	}else if(browser.equalsIgnoreCase("Edge")) {
			EdgeOptions options2 = new EdgeOptions();
			options2.addArguments("--disable-notifications");
			options2.addArguments("--disable-popup-blocking");
			driver = new EdgeDriver(options2);
			driver.manage().window().maximize();
			System.out.println("Edge is Launched");
		}
	}
 
	// Launching Website
	
	public void getUrl() {
		driver.get("https://www.pepperfry.com/");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
 
	}
 
	// Verifying the title of the webpage
 
	public void verify() throws InterruptedException {
		String expResult = "Online Furniture Shopping Store: Shop Online in India for Furniture, Home Decor, Homeware Products @ Pepperfry";
		String actResult = driver.getTitle();
		Thread.sleep(2000);
		if (actResult.equalsIgnoreCase(expResult)) {
			System.out.println("Correct Website is Launched");
		} else {
			System.out.println("Incorrect Website is Launched");
			 driver.quit();
			System.exit(0);
		}
	}
	
	//Select “Furniture” and click on “Settees & Benches”.
	
	public void selectCategory() throws InterruptedException {
		WebElement furniture = driver.findElement(By.name("Furniture"));
		Actions action = new Actions(driver);
		action.moveToElement(furniture).perform();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[@href='/category/settees-and-benches.html?type=hover-furniture-setteesbenches']")).click();
	}
	
//	Display the Count of benches.
//	Display the count of settees.
//	Display the count of recamiers.	
	
	public void displayingCount() throws InterruptedException {
		String[] scount = driver.findElement(By.xpath("(//div[@class='clip-catg-content text-xs font-medium color-secondary ng-star-inserted'])[2]")).getText().split(" ");
		Thread.sleep(2000);
		String[] bcount = driver.findElement(By.xpath("(//div[@class='clip-catg-content text-xs font-medium color-secondary ng-star-inserted'])[3]")).getText().split(" ");
		Thread.sleep(2000);
		String[] rcount = driver.findElement(By.xpath("(//div[@class='clip-catg-content text-xs font-medium color-secondary ng-star-inserted'])[4]")).getText().split(" ");
		Thread.sleep(2000);
		
		System.out.println("Options for Seaters  : " + scount[0]);
		System.out.println("Options for Benched  : " + bcount[0]);
		System.out.println("Options for Recaimers: " + rcount[0]);
	}
	
//	Click on “Filter By” -> Materials.
//  Click on “Metal Benches”.
	
	public void filter() throws InterruptedException {
		driver.findElement(By.xpath("//a[@href='/category/benches.html']")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("Material")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//label[@for='Metal']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//button[@id='Button'])[3]")).click();
		Thread.sleep(2000);
	}
	
//	Display the benches,  display the count as well in console
	
	public void products() throws IOException, InterruptedException {
		List<WebElement> product = driver.findElements(By.xpath("//div[@class='pf-col xs-6 sm-3 clip-product-card-wrapper marginBottom-12 ng-star-inserted']"));
		System.out.println("Count of Metal Benches: "+ product.size());
		Thread.sleep(10000);
		
	}
	
//	Scrolling page to take Screenshot of displayed  benches
//	take the screenshot 
	
	public void ss() throws IOException, InterruptedException{
		Actions action = new Actions(driver);
		action.sendKeys(Keys.PAGE_DOWN).build().perform();
		Thread.sleep(5000);
		TakesScreenshot screenshot = (TakesScreenshot)driver;
		File source = screenshot.getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(source, new File("C:/SeliniumScreenshots/Screen.png"));
		System.out.println("Screenshot is captured and saved successfully");
		
	}
	
	//Close the browser
	
	public void closeBrowser() throws InterruptedException {
		Thread.sleep(5000);
        driver.quit();
		System.out.println("Browser Closed Successfully");
	}
}
 