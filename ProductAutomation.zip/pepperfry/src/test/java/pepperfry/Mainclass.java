package pepperfry;

import java.util.Scanner;

import org.openqa.selenium.WebDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Mainclass {
 
	public static void main(String[] args) throws Exception {
		ProductListAutomation pla = new ProductListAutomation();
		
		WebDriverManager.chromedriver().setup();
		Scanner scanner=new Scanner(System.in);
		System.out.print("Enter the Browser (Chrome/Edge) : ");
		String browser=scanner.nextLine();
		
		pla.Driver(browser);
		pla.getUrl();
		pla.verify();
		pla.selectCategory();
		pla.displayingCount();
		pla.filter();
		pla.products();
		pla.ss();
		pla.closeBrowser();
	}
}