package testBase;
 
import java.time.Duration;
 
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
 
public class BaseClass {
	public WebDriver driver;
	@Parameters({"browser"})
	@BeforeClass
	public void setup(String browser) throws InterruptedException {
		switch (browser) {
		case "Chrome":
			driver = new ChromeDriver();
			System.out.println("Chrome is Launched.");
			break;
 
		case "Edge":
			driver = new EdgeDriver();
			System.out.println("Edge is Launched");
			break;
 
		}
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		driver.get("https://Be.Cognizant.com/");
		Thread.sleep(35000);
		String actTitle = driver.getTitle();
		if (actTitle.equals("Be.Cognizant - Home")) {
			System.out.println("Correct Website is Launched");
		} else {
			System.out.println("Incorrect Website is Launched");
			System.exit(0);
		}
	}
	@AfterClass
	public void teardown() {
		driver.quit();
		System.out.println("Browser Closed Successfully");
	}
}