package pageObjects;
 
import java.util.List;
 
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
 
public class NewsCogPage extends BasePage{
 
	public NewsCogPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}
 
	@FindBy(id = "news_text_title")
	List<WebElement> Title;
	public List<WebElement> titles() {
		return Title;
	}
}