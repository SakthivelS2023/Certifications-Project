package pageObjects;
 
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
 
public class NewsPage extends BasePage{
 
	public NewsPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}
 
	@FindBy(id="title_text")
	WebElement NewsTitle;
	@FindBy(xpath = "/html/body/div/div[2]/div[2]/div/div[2]/div[4]/section/article/div/div/div/div[2]/div[1]/div/div/div/div/div/div/div/div[1]/div[2]")
	WebElement NewsContent;
	public String getNewsTitle() {
		return NewsTitle.getText();
	}
	public String getNewsContent() {
		return NewsContent.getText();
	}
}