package pageObjects;
 
import java.util.List;
 
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
 
public class BeCogHomePage extends BasePage {
	WebDriver Driver;
	public BeCogHomePage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}	
	//Elements
	@FindBy(id= "O365_MainLink_Me")
	WebElement ProfileBeforeClick;
	@FindBy(id = "mectrl_currentAccount_primary")
	WebElement UserName;
	@FindBy(id = "mectrl_currentAccount_secondary")
	WebElement UserMail;
	@FindBy(id= "mectrl_headerPicture")
	WebElement ProfileAfterClick;
	@FindBy(xpath = "//*[@id=\"5d7d4eec-cbe0-4c55-ae2e-f38d926d82a0\"]/div/div/div/p/span/strong")
	WebElement Scroll1;
	@FindBy(xpath= "//div[@class='ar_b_91bed31b']/div[1]/div[2]/a")
	List<WebElement> AroundCognizant;
	@FindBy(xpath= "//a[@href='/sites/Be.Cognizant/_layouts/15/news.aspx']")
	WebElement Scroll2;
	@FindBy(xpath = "//a[@href='/sites/Be.Cognizant/_layouts/15/news.aspx']")
	WebElement seeAll;
	//Action Methods
	public void ProfileBeforeClick() throws Exception {
		ProfileBeforeClick.click();
		Thread.sleep(2000);
		
	}
	public String getUserName() {
		String uName = UserName.getText();
		System.out.println(uName);
		return uName;
	}
	public String getUserMail() {
		String uMail = UserMail.getText();
		System.out.println(uMail);
		return uMail;
	}
	public void ProfileAfterClick() {
		ProfileAfterClick.click();
	}
	public void Scroll1() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView()",Scroll1);
	}
	public List<WebElement> titleInAroundCognizant() {
		return AroundCognizant;
	}
	public void Scroll2() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView()",Scroll2);
	}
	public void clickOneSeeall() {
		seeAll.click();
	}
}