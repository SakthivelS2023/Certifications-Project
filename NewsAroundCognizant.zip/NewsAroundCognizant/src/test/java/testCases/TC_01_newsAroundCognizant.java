package testCases;
 
import java.io.IOException;
import java.util.List;
 
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;
 
import pageObjects.BeCogHomePage;
import pageObjects.NewsCogPage;
import pageObjects.NewsPage;
import testBase.BaseClass;
import utilities.ExcelUtilities;
import utilities.TakeScreenshot;
 
public class TC_01_newsAroundCognizant extends BaseClass {
 
	@Test(priority=1)
	public void VerifyUser() throws Exception {
		BeCogHomePage bchp = new BeCogHomePage(driver);
		bchp.ProfileBeforeClick();
		String userName = bchp.getUserName();
		String userMail = bchp.getUserMail();
		TakeScreenshot.TakeScrShot(driver);
		if (userName.contains("Cognizant") && userMail.contains("@cognizant.com")) {
			System.out.println("Verified User");
		} else {
			System.out.println("Not a Verified user");
		}
		bchp.ProfileAfterClick();
	}
	@Test(priority=2)
	public void AroundNewsCog() throws Exception {
		BeCogHomePage bchp = new BeCogHomePage(driver);
		bchp.Scroll1();
		TakeScreenshot.TakeScrShot(driver);
		if (driver.getPageSource().contains("Around Cognizant")) {
			System.out.println("\"Around Cognizant\" is present in Webpage");
			Thread.sleep(2000);
		} else {
			System.out.println("\"Around Cognizant\" is not present in Webpage");
			Thread.sleep(2000);
			driver.quit();
			System.exit(0);
		}
	}
	@Test(priority=3)
	public void verifyHomeNews() throws InterruptedException, IOException {
		BeCogHomePage bchp = new BeCogHomePage(driver);
		Thread.sleep(2000);
		List<WebElement> homeNews = bchp.titleInAroundCognizant();
		System.out.println("Count of the NEWS displayed: " + homeNews.size());
		int i=0;
		for(WebElement news:homeNews) {
			String newsTitle=news.getText();
			String act_tooltip=news.getAttribute("title");
			if(act_tooltip.equals(newsTitle)) {
				System.out.println(newsTitle);
				System.out.println("Tool Tip matched");
				ExcelUtilities.write(++i, 0, newsTitle);
			}else {
				System.out.println("Tool Tip mismatched");
			}
		}
	}
	@Test(priority=4)
	public void seeAllFunction() throws Exception {
		BeCogHomePage bchp = new BeCogHomePage(driver);
		TakeScreenshot.TakeScrShot(driver);
		bchp.Scroll2();
		bchp.clickOneSeeall();
		Thread.sleep(10000);
	}
	@Test(priority=5)
	public void Top5NewsTitles() throws Exception {
		NewsCogPage ncp = new NewsCogPage(driver);
		NewsPage np = new NewsPage(driver);
		Thread.sleep(10000);
		List<WebElement> title = ncp.titles();
		System.out.println("No. of news captured: "+title.size());
		Thread.sleep(10000);
		int j=1;
		for(int i=0; i<=6; i++) {
			if(i==1 || i==4) {
				continue;
			}else {
				System.out.println("============================================================================================================");
				title=driver.findElements(By.id("news_text_title"));
				WebElement we = title.get(i);
				String exp_title = we.getText();
				we.click();
				Thread.sleep(2000);
				JavascriptExecutor JS = (JavascriptExecutor)driver;
				JS.executeScript("window.scrollBy(0,400)", "");
				
				String content = np.getNewsContent();
				String act_Title = np.getNewsTitle();
					if(exp_title.equalsIgnoreCase(act_Title)) {
						System.out.println(exp_title);
						System.out.println(content);
						TakeScreenshot.TakeScrShot(driver);
						ExcelUtilities.write(j, 1, exp_title);
						ExcelUtilities.write(j, 2, content);
						System.out.println("============================================================================================================");
						j++;
					}
				driver.navigate().back();
				Thread.sleep(5000);
			}
		}
	}
}