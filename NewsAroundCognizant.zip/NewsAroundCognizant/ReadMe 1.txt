Topic Name: News Around Cognizant
 
Problem Statement: print and verify the news present in Be.Cognizant page  

News Around Cognizant 

Detailed Description: 
-Login to be.cognizant.com with a valid user information (userID and Email ID) 
-Verify if the name and Email of the employee contains cognizant or not.
-Verify "Around Cognizant" is displayed or not
-Print all the news headers and verify the tool tip and header value whether it is diplaying correctly or not
-you should get all the information of the news
-Click on the SEE ALL
-Click on the top 5 news which are displayed
-You should get all the information which is present in the each news
-After navigate back and you should verify whether it is navigate back to the be.cogniant home page or not 
-Click on the 2nd news and get all the information Navigate back and do the same for remaining news (Top 5).
  
 
Key Automation Scope:  
-Extract news items & store in collections 
-Handling different browser windows
-Navigating pages
-Scrolling down in webPage
-Taking ScreenShots 

 
 
About this Project:
Project folder	:NewsAroundCognizant 

src/test/java	:Contains 4 packages and each package have different classes
			1)pageObjects
				-BasePage.java
				-BeCogHomePage.java
				-NewsCogPage.java
				-NewsPage.java
			2)testBase
				-BaseClass.java
			3)testCases
				-TC_01_newsAroundCognizant.java
			4)utilities
				-ExcelUtilities.java
				-ExtentReportManager.java
				-TakeScreenshot.java
	
Reports		:Contains-
			1)ScreenShot folder
		 	2)ExcelOutput.xlsx
		 	3)TestNG_ExtentReport

test-output	:Contains-
			1)pom.xml
			2)testng.xml
			3)other files
 
Tools and Technologies used:

-Selenium with Java in Eclipse IDE
-TestNG
-Maven
-WebDriverManager
-ExtentReports
-Apache POI

 
By:
Naveenkumar Nagaraj
Navyatha Pyla
Mathivanan Shanmugham
Sakthivel S


 